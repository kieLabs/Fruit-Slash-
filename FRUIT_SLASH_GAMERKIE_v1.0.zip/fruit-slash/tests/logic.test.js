import test from 'node:test';
import assert from 'node:assert/strict';
import { segmentCircle, splitImpulse } from '../slicing.js';
import { generateLevel } from '../levels.js';
import { getDifficulty, getDifficultyBand } from '../difficulty.js';
import { defaultSave, loadSave, mergeSafe } from '../save.js';
import { purchaseItem, getShopItems } from '../shop.js';

test('swipe segment detects a fruit intersected between pointer samples', () => {
  assert.equal(segmentCircle(0, 10, 100, 10, 50, 12, 5), true);
  assert.equal(segmentCircle(0, 10, 100, 10, 50, 30, 5), false);
});

test('split impulse is perpendicular to the swipe direction and finite', () => {
  const result = splitImpulse(0, 0, 10, 0, 500);
  assert.ok(Math.abs(result.nx) < 1e-9);
  assert.equal(result.ny, 1);
  assert.ok(Number.isFinite(result.force));
  assert.ok(result.force <= 360);
});

test('procedural levels keep increasing targets without a hard level cap', () => {
  const one = generateLevel(1, 7);
  const fifty = generateLevel(50, 7);
  const thousand = generateLevel(1000, 7);
  assert.equal(one.number, 1);
  assert.ok(fifty.targetScore > one.targetScore);
  assert.ok(thousand.number === 1000);
  assert.ok(thousand.pattern.length > 0);
  assert.ok(thousand.bombProbability <= 0.24);
});

test('same level and seed produces a repeatable wave pattern', () => {
  assert.deepEqual(generateLevel(42, 1234).pattern, generateLevel(42, 1234).pattern);
});

test('difficulty rises while spawn interval and bomb chance remain bounded', () => {
  const early = getDifficulty(1);
  const late = getDifficulty(100000);
  assert.ok(late.fruitSpeed >= early.fruitSpeed);
  assert.ok(late.spawnInterval >= 0.54);
  assert.ok(late.bombChance <= 0.24);
  assert.equal(getDifficultyBand(501), 'Endless');
});

test('save loader safely falls back when storage data is invalid', () => {
  const fakeStorage = { getItem: () => '{invalid json' };
  const loaded = loadSave(fakeStorage);
  assert.equal(loaded.level, 1);
  assert.equal(loaded.coins, 120);
  assert.ok(Array.isArray(loaded.unlockedBlades));
});

test('save migration merges nested settings without dropping defaults', () => {
  const source = { version:1, coins:55, settings:{sound:false} };
  const merged = mergeSafe(defaultSave(), source);
  assert.equal(merged.coins,55);
  assert.equal(merged.settings.sound,false);
  assert.equal(merged.settings.music,true);
  assert.equal(merged.level,1);
});

test('shop charges coins and equips a purchased cosmetic item', () => {
  const save = defaultSave();
  save.coins = 500;
  const blade = getShopItems('blades').find(item => item.id === 'fire');
  const result = purchaseItem(save,'blades',blade);
  assert.equal(result.ok,true);
  assert.equal(save.equippedBlade,'fire');
  assert.equal(save.coins,500-blade.cost);
});

test('power-up purchase adds inventory and deducts its coin cost', () => {
  const save = defaultSave();
  const power = getShopItems('powerups').find(item => item.id === 'freeze');
  const before = save.powerupInventory.freeze;
  const result = purchaseItem(save,'powerups',power);
  assert.equal(result.ok,true);
  assert.equal(save.powerupInventory.freeze,before+1);
  assert.equal(save.coins,120-power.cost);
});

test('fruit catalogue includes all twenty named fruit types', async () => {
  const { FRUITS } = await import('../fruits.js');
  assert.equal(FRUITS.length,20);
  assert.ok(FRUITS.some(f => f.id === 'dragonfruit'));
  assert.ok(FRUITS.some(f => f.id === 'passionfruit'));
});

test('every mode, blade and background collection has selectable entries', async () => {
  const { MODES } = await import('../modes.js');
  const { BLADES } = await import('../blades.js');
  const { BACKGROUNDS } = await import('../shop.js');
  assert.equal(Object.keys(MODES).length,5);
  assert.equal(BLADES.length,10);
  assert.equal(BACKGROUNDS.length,10);
});
