# FRUIT SLASH – GamerKie Edition

A mobile-first fruit-slicing arcade game built with HTML5 Canvas, CSS and vanilla JavaScript modules. It has no build step and no runtime framework dependency.

## Run locally

Because the project uses JavaScript ES modules, run it through a local web server or GitHub Pages (do not launch the file directly with a `file://` URL). For example:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## GitHub Pages

1. Create a repository named `fruit-slash`.
2. Upload the contents of this folder (not the outer ZIP folder).
3. In **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`.
4. Open the Pages URL after deployment finishes.

## Blogger embed

Host the game on GitHub Pages, then use this in a Blogger HTML view:

```html
<div style="max-width:440px;margin:0 auto;aspect-ratio:9/16;overflow:hidden;border-radius:18px">
  <iframe src="https://YOUR-USERNAME.github.io/fruit-slash/" title="FRUIT SLASH – GamerKie Edition" loading="lazy" allow="fullscreen; gamepad" style="width:100%;height:100%;border:0"></iframe>
</div>
```

Replace `YOUR-USERNAME` with your GitHub username. The iframe host must serve the game over HTTPS for best mobile behavior.

## Controls

- **Mobile:** swipe across the canvas to slice. Multi-touch is supported.
- **Desktop:** hold the left mouse button and drag.
- **Pause:** tap the `Ⅱ` HUD button or press `Escape`.
- **Fullscreen:** use the ⛶ button in the page header.

## Included in this build

- Canvas game loop with delta-time updates, touch/mouse slicing, fruit physics, split halves, juice/seed/spark particles and bombs.
- Twenty procedurally drawn fruit types and six special-fruit effects.
- Classic, Arcade, Zen, Survival and Challenge modes.
- Endless procedural campaign level generation with increasing score targets and bounded difficulty.
- Combo scoring, 3-star level results, coins, gems, blades, backgrounds, power-up inventory, daily missions, achievements, profile statistics and versioned localStorage saves.
- Generated Web Audio sound effects and simple synthesized background music.
- Responsive portrait-first layout, fullscreen support and Blogger iframe compatibility.

## Verification

Run the logic tests with:

```bash
npm test
```

The game stores progress in this browser's localStorage. Clearing browser site data will clear local progress. This build uses original procedural artwork and generated audio; it does not bundle copyrighted Fruit Ninja media.

## Current scope notes

This is a functional first release, not a claim of parity with a commercial game. Fruit interiors, cut visuals and backgrounds are drawn procedurally rather than from photorealistic art assets. Some advanced effects and challenge variety remain intentionally simplified; see the final handoff notes from the project creator.
