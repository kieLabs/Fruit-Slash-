# Assets

This release intentionally uses procedural Canvas artwork and Web Audio-generated effects, so it does not require external image or audio files. Add future licensed assets in the matching `fruits/`, `backgrounds/`, `blades/`, `particles/`, `sounds/`, or `ui/` folders and wire them through the relevant module.
