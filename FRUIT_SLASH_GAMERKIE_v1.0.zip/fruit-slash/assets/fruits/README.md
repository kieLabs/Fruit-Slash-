# Fruits assets

This folder is reserved for optional licensed assets. The current game renders this content procedurally in Canvas and Web Audio.
